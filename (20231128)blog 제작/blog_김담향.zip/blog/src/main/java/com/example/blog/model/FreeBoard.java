package com.example.blog.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class FreeBoard {
    @Id
    private long seq;
    private String title;
    private String content;
    private String memberId;
    private String regDate;
}
